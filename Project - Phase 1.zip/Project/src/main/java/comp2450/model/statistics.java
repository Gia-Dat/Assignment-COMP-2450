package comp2450.model;

import com.google.common.base.Preconditions;

/**
 * Stores activity statistics including time and distance.
 */

public class statistics {
    private final int time;
    private final double length;

    public statistics(int time, double length) {
        // Preconditions
        Preconditions.checkArgument(time > 0, "Time must be positive");
        Preconditions.checkArgument(length > 0, "Length must be positive");

        this.time = time;
        this.length = length;
    }

    public double averageTime() {
        // Invariant check
        Preconditions.checkState(time > 0, "Invariant violated: time must be positive");
        Preconditions.checkState(length > 0, "Invariant violated: length must be positive");

        return (double) time;
    }

    public double averageLength() {
        // Invariant check
        Preconditions.checkState(time > 0, "Invariant violated: time must be positive");
        Preconditions.checkState(length > 0, "Invariant violated: length must be positive");

        return length;
    }

    public int getTime() {
        Preconditions.checkState(time > 0, "Invariant violated: time must be positive");
        return time;
    }

    public double getLength() {
        Preconditions.checkState(length > 0, "Invariant violated: length must be positive");
        return length;
    }
}
