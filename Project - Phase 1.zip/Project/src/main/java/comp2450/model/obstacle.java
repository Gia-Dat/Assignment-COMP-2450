package comp2450.model;

import com.google.common.base.Preconditions;

/**
 * Represents an obstacle with a name and position on the map.
 */

public class obstacle {
    private final String name;
    private final coordinate obstaclePosition;

    public obstacle(String name, coordinate obstaclePosition) {
        // Preconditions
        Preconditions.checkNotNull(name, "Name must not be null");
        Preconditions.checkArgument(name.length() >= 1, "Name must not be empty");
        Preconditions.checkNotNull(obstaclePosition, "obstaclePosition must not be null");

        this.name = name;
        this.obstaclePosition = obstaclePosition;
    }

    public String getName() {
        // Invariant check
        Preconditions.checkState(name != null && name.length() >= 1,
                "Invariant violated: Name must not be null or empty");
        return name;
    }

    public coordinate getObstacleCoordinate() {
        // Invariant check
        Preconditions.checkState(obstaclePosition != null,
                "Invariant violated: obstaclePosition must not be null");
        return obstaclePosition;
    }
}
