package comp2450.model;

import com.google.common.base.Preconditions;

/**
 * Represents a route between two coordinates on a map.
 */

public class route {
    private final coordinate start;
    private final coordinate end;

    public route(coordinate start, coordinate end) {
        // Preconditions
        Preconditions.checkNotNull(start, "Start coordinate must not be null");
        Preconditions.checkNotNull(end, "End coordinate must not be null");
        Preconditions.checkArgument(!start.equals(end),
                "Start and end coordinates must be different");

        this.start = start;
        this.end = end;
    }

    public boolean checkRoute() {
        // Invariant check
        Preconditions.checkState(start != null, "Invariant violated: start must not be null");
        Preconditions.checkState(end != null, "Invariant violated: end must not be null");
        Preconditions.checkState(!start.equals(end),
                "Invariant violated: start and end must be different");

        return true; // Simplified validation
    }

    public coordinate getStart() {
        Preconditions.checkState(start != null, "Invariant violated: start must not be null");
        return start;
    }

    public coordinate getEnd() {
        Preconditions.checkState(end != null, "Invariant violated: end must not be null");
        return end;
    }
}
