package comp2450.model;

import com.google.common.base.Preconditions;

/**
 * Represents a gear item with name, quality, and type.
 */

public class gear {
    private final String name;
    private int quality;
    private final gearType type;

    public gear(String name, int quality, gearType type) {
        // Preconditions
        Preconditions.checkNotNull(name, "Name must not be null");
        Preconditions.checkArgument(name.length() >= 1, "Name must not be empty");
        Preconditions.checkArgument(quality >= 0, "Quality must be non-negative");
        Preconditions.checkNotNull(type, "Gear type must not be null");

        this.name = name;
        this.quality = quality;
        this.type = type;
    }

    public void changeQuality(int newQuality) {
        // Preconditions
        Preconditions.checkArgument(newQuality >= 0, "Quality must be non-negative");

        int oldQuality = this.quality;
        this.quality = newQuality;

        // Postconditions
        Preconditions.checkState(this.quality != oldQuality,
                "Postcondition failed: quality should have changed");
    }

    public String getName() {
        // Invariant check
        Preconditions.checkState(name != null && name.length() >= 1,
                "Invariant violated: Name must not be null or empty");
        return name;
    }

    public gearType type() {
        // Invariant check
        Preconditions.checkState(type != null,
                "Invariant violated: Gear type must not be null");
        return type;
    }

    public int getQuality() {
        // Invariant check
        Preconditions.checkState(quality >= 0,
                "Invariant violated: Quality must be non-negative");
        return quality;
    }
}