package comp2450.model;

import com.google.common.base.Preconditions;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Main menu system for managing gear, activities, maps, and statistics.
 */

public class menu {
    private final String userName;
    private final ArrayList<gear> items;
    private final ArrayList<activity> exercise;
    private final ArrayList<map> mymap;
    private final ArrayList<statistics> stat;
    private final Scanner scanner;
    private boolean running;

    public menu(String userName) {
        // Preconditions
        Preconditions.checkNotNull(userName, "userName must not be null");
        Preconditions.checkArgument(userName.length() >= 1, "userName must not be empty");

        this.userName = userName;
        this.items = new ArrayList<>();
        this.exercise = new ArrayList<>();
        this.mymap = new ArrayList<>();
        this.stat = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.running = true;
    }

    public void start() {
        System.out.println("=== Activity Tracker System ===");
        System.out.println("Welcome, " + userName + "!");

        while (running) {
            showMainMenu();
            System.out.print("Enter your choice (1-13): ");
            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("13") || input.equalsIgnoreCase("exit")) {
                break;
            }

            try {
                int choice = Integer.parseInt(input);
                processMenuChoice(choice);
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a number between 1-13");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            System.out.println();
        }

        scanner.close();
        System.out.println("Goodbye!");
    }

    private void showMainMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Add Gear");
        System.out.println("2. Show All Gear");
        System.out.println("3. Remove Gear");
        System.out.println("4. Add Activity");
        System.out.println("5. Show All Activities");
        System.out.println("6. Remove Activity");
        System.out.println("7. Add Map");
        System.out.println("8. Show All Maps");
        System.out.println("9. Remove Map");
        System.out.println("10. Add Statistic");
        System.out.println("11. Show Statistics");
        System.out.println("12. Remove Statistic");
        System.out.println("13. Exit");
    }

    private void processMenuChoice(int choice) {
        Preconditions.checkArgument(choice >= 1 && choice <= 13,
                "Choice must be between 1-13");

        switch (choice) {
            case 1: addGear(null); break;
            case 2: showGear(true); break;
            case 3: removeGear(null); break;
            case 4: addActivity(null); break;
            case 5: showActivity(true); break;
            case 6: removeActivity(null); break;
            case 7: addMap(null); break;
            case 8: showMap(true); break;
            case 9: removeMap(null); break;
            case 10: addStat(null); break;
            case 11: showStat(true); break;
            case 12: removeStat(null); break;
            case 13: running = false; break;
            default: System.out.println("Invalid choice.");
        }
    }

    public void addGear(gear newGear) {
        if (newGear == null) {
            System.out.println("\n--- Add New Gear ---");

            System.out.print("Enter gear name: ");
            String name = scanner.nextLine().trim();
            Preconditions.checkArgument(!name.isEmpty(), "Gear name cannot be empty");

            System.out.print("Enter gear quality (0-100): ");
            int quality = Integer.parseInt(scanner.nextLine().trim());
            Preconditions.checkArgument(quality >= 0 && quality <= 100,
                    "Quality must be between 0-100");

            System.out.println("Select gear type:");
            System.out.println("1. SUPPORT");
            System.out.println("2. PROTECTION");
            System.out.println("3. NUTRITION");
            System.out.print("Enter choice (1-3): ");
            int typeChoice = Integer.parseInt(scanner.nextLine().trim());

            gearType type = switch (typeChoice) {
                case 1 -> gearType.SUPPORT;
                case 2 -> gearType.PROTECTION;
                case 3 -> gearType.NUTRITION;
                default -> throw new IllegalArgumentException("Invalid gear type selection");
            };

            newGear = new gear(name, quality, type);
            System.out.println("✓ Gear added successfully: " + name);
        }


        Preconditions.checkNotNull(newGear, "newGear must not be null");
        items.add(newGear);

        // Postcondition
        Preconditions.checkState(items.contains(newGear),
                "Postcondition failed: gear not added");
    }


    public ArrayList<gear> showGear(boolean interactive) {
        ArrayList<gear> gearList = new ArrayList<>(items);

        if (interactive) {
            System.out.println("\n--- All Gear ---");
            if (gearList.isEmpty()) {
                System.out.println("No gear available.");
            } else {
                for (int i = 0; i < gearList.size(); i++) {
                    gear g = gearList.get(i);
                    System.out.println((i + 1) + ". " + g.getName() +
                            " - Quality: " + g.getQuality() + " - Type: " + g.type());
                }
            }
        }

        return gearList;
    }

    public void removeGear(gear oldGear) {
        if (oldGear == null) {
            ArrayList<gear> gearList = showGear(true);
            if (gearList.isEmpty()) {
                System.out.println("No gear available to remove.");
                return;
            }
            System.out.print("Enter the number of gear to remove: ");
            int choice = Integer.parseInt(scanner.nextLine().trim());
            Preconditions.checkArgument(choice >= 1 && choice <= gearList.size(),
                    "Invalid gear selection");

            oldGear = gearList.get(choice - 1);
            System.out.println("✓ Gear removed: " + oldGear.getName());
        }

        Preconditions.checkNotNull(oldGear, "oldGear must not be null");
        Preconditions.checkState(items.contains(oldGear), "Gear must exist");

        boolean removed = items.remove(oldGear);
        Preconditions.checkState(removed, "Postcondition failed: gear not removed");
    }

    public void addActivity(activity newAc) {
        if (newAc == null) {
            System.out.println("\n--- Add New Activity ---");

            System.out.print("Enter activity name: ");
            String name = scanner.nextLine().trim();
            Preconditions.checkArgument(!name.isEmpty(), "Activity name cannot be empty");
            newAc = new activity(name);
            System.out.println("✓ Activity added successfully: " + name);
        }
        Preconditions.checkNotNull(newAc, "newAc must not be null");
        exercise.add(newAc);

        // Postcondition
        Preconditions.checkState(exercise.contains(newAc),
                "Postcondition failed: activity not added");
    }


    public ArrayList<activity> showActivity(boolean interactive) {
        ArrayList<activity> activityList = new ArrayList<>(exercise);

        if (interactive) {
            System.out.println("\n--- All Activities ---");
            if (activityList.isEmpty()) {
                System.out.println("No activities available.");
            } else {
                for (int i = 0; i < activityList.size(); i++) {
                    activity a = activityList.get(i);
                    System.out.println((i + 1) + ". " + a.getName());
                }
            }
        }

        return activityList;
    }
    public void removeActivity(activity oldAc) {
        if (oldAc == null) {
            ArrayList<activity> activityList = showActivity(true);
            if (activityList.isEmpty()) {
                System.out.println("No activities available to remove.");
                return;
            }

            System.out.print("Enter the number of activity to remove: ");
            int choice = Integer.parseInt(scanner.nextLine().trim());
            Preconditions.checkArgument(choice >= 1 && choice <= activityList.size(),
                    "Invalid activity selection");

            oldAc = activityList.get(choice - 1);
            System.out.println("✓ Activity removed: " + oldAc.getName());
        }
        Preconditions.checkNotNull(oldAc, "oldAc must not be null");
        Preconditions.checkState(exercise.contains(oldAc), "Activity must exist");

        boolean removed = exercise.remove(oldAc);

        // Postcondition
        Preconditions.checkState(removed, "Postcondition failed: activity not removed");
    }

    public void addMap(map newMap) {
        if (newMap == null) {
            System.out.println("\n--- Add New Map ---");

            System.out.print("Enter map name: ");
            String name = scanner.nextLine().trim();
            Preconditions.checkArgument(!name.isEmpty(), "Map name cannot be empty");

            // Ask for grid size
            try {
                System.out.print("Enter grid width (default 10): ");
                int width = Integer.parseInt(scanner.nextLine().trim());
                System.out.print("Enter grid height (default 10): ");
                int height = Integer.parseInt(scanner.nextLine().trim());

                newMap = new map(name, width, height);
            } catch (Exception e) {
                // Use default size if invalid input
                newMap = new map(name);
            }

            System.out.println("✓ Map added successfully: " + name);
        }
        Preconditions.checkNotNull(newMap, "newMap must not be null");
        mymap.add(newMap);
    }

    public ArrayList<map> showMap(boolean interactive) {
        ArrayList<map> mapList = new ArrayList<>(mymap);

        if (interactive) {
            System.out.println("\n--- All Maps ---");
            if (mapList.isEmpty()) {
                System.out.println("No maps available.");
            } else {
                for (int i = 0; i < mapList.size(); i++) {
                    map m = mapList.get(i);
                    System.out.println((i + 1) + ". " + m.getName() + " (" + m.getGridWidth() + "x" + m.getGridHeight() + ")");
                }

                // Ask user if they want to adjust a map
                Scanner scanner = new Scanner(System.in);
                System.out.print("\nDo you want to adjust a map? (yes/no): ");
                String response = scanner.nextLine().trim().toLowerCase();

                if (response.equals("yes") || response.equals("y")) {
                    // Let user select a map for interactive management
                    try {
                        System.out.print("Select a map to adjust (enter number): ");
                        int choice = scanner.nextInt();
                        scanner.nextLine(); // consume newline

                        if (choice > 0 && choice <= mapList.size()) {
                            map selectedMap = mapList.get(choice - 1);
                            selectedMap.manageObstaclesInteractive();
                        } else {
                            System.out.println("Invalid map selection.");
                        }
                    } catch (Exception e) {
                        System.out.println("Invalid input. Please enter a number.");
                        scanner.nextLine(); // clear invalid input
                    }
                } else {
                    System.out.println("Returning to comp2450.main menu...");
                }
            }
        }

        return mapList;
    }

    public void removeMap(map oldMap) {
        if (oldMap == null) {
            ArrayList<map> mapList = showMap(true);
            if (mapList.isEmpty()) {
                System.out.println("No maps available to remove.");
                return;
            }

            System.out.print("Enter the number of map to remove: ");
            int choice = Integer.parseInt(scanner.nextLine().trim());
            Preconditions.checkArgument(choice >= 1 && choice <= mapList.size(),
                    "Invalid map selection");

            oldMap = mapList.get(choice - 1);
            System.out.println("✓ Map removed: " + oldMap.getName());
        }
        Preconditions.checkNotNull(oldMap, "oldMap must not be null");
        Preconditions.checkState(mymap.contains(oldMap), "Map must exist");

        boolean removed = mymap.remove(oldMap);

        // Postcondition
        Preconditions.checkState(removed, "Postcondition failed: map not removed");
    }

    public void addStat(statistics newStat){
        if (newStat == null){
            System.out.print("Enter activity duration (minutes): ");
            int duration = Integer.parseInt(scanner.nextLine().trim());
            Preconditions.checkArgument(duration > 0, "Duration must be positive");

            System.out.print("Enter distance (km): ");
            double distance = Double.parseDouble(scanner.nextLine().trim());
            Preconditions.checkArgument(distance > 0, "Distance must be positive");

            newStat = new statistics(duration, distance);
            System.out.println("✓ Stat added successfully");
        }
        Preconditions.checkNotNull(newStat, "newStat must not be null");
        stat.add(newStat);

        Preconditions.checkState(stat.contains(newStat),
                "Postcondition failed: Statistic for this session not added");
    }


    public void removeStat(statistics oldStat) {
        if (oldStat == null) {
            ArrayList<statistics> statisticList = showStat(true);
            if (statisticList.isEmpty()) {
                System.out.println("No records available to remove.");
                return;
            }

            System.out.print("Enter the number of record to remove: ");
            int choice = Integer.parseInt(scanner.nextLine().trim());
            Preconditions.checkArgument(choice >= 1 && choice <= statisticList.size(),
                    "Invalid record selection");

            oldStat = statisticList.get(choice - 1);
            System.out.println("✓ Record removed: ");
        }
        Preconditions.checkNotNull(oldStat, "oldStat must not be null");
        Preconditions.checkState(stat.contains(oldStat), "Record must exist");

        boolean removed = stat.remove(oldStat);

        // Postcondition
        Preconditions.checkState(removed, "Postcondition failed: record not removed");
    }

    public ArrayList<statistics> showStat(boolean interactive) {
        ArrayList<statistics> statsList = new ArrayList<>(stat);

        if (interactive) {
            System.out.println("\n--- Statistics ---");
            if (statsList.isEmpty()) {
                System.out.println("No statistics available.");
            } else {
                double totalTime = 0;
                double totalLength = 0;

                for (int i = 0; i < statsList.size(); i++) {
                    statistics s = statsList.get(i);
                    totalTime += s.getTime();
                    totalLength += s.getLength();
                    System.out.println((i + 1) + ". Time: " + s.getTime() +
                            " min, Length: " + s.getLength() + " km");
                }

                System.out.println("\n--- Summary ---");
                System.out.println("Total Activities: " + statsList.size());
                System.out.println("Total Time: " + totalTime + " minutes");
                System.out.println("Total Distance: " + totalLength + " km");
                if (statsList.size() > 0) {
                    System.out.println("Average Time: " + String.format("%.1f", totalTime / statsList.size()) + " minutes per activity");
                    System.out.println("Average Distance: " + String.format("%.1f", totalLength / statsList.size()) + " km per activity");
                }
            }
        }

        return statsList;
    }


    public String getUserName() {
        // Invariant check
        Preconditions.checkState(userName != null && userName.length() >= 1,
                "Invariant violated: userName must not be null or empty");
        return userName;
    }

}