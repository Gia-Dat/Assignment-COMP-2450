package comp2450.model.exceptions;

public class ObstacleCollisionException extends Exception{
}
