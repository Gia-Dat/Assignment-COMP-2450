package comp2450.model;

/**
 * Represents an activity with a name.
 */

public record activity (String name) {
    public String getName() {return name; }
}