---
title: Activity-Tracker-System
author: Gia Dat Ly (lygd@myumanitoba.ca)
date: Fall 2025
---
# Overview

    Activity Tracker System is an implementation for COMP 2450 in Fall 2025.
    It helps the user to track when exercising and calculate some statistics 
    to give them insights help them make right decision on their health

# Runnning

This project was developed using IntelliJ IDEA and uses Maven, so there are two
ways to run it:

1. Open the class called `main.java` and click the green play button on the
   `comp2450.main`method, or
2. Run Maven on the command line:
   ```
   mvn compile exec:java '-Dexec.mainClass=comp2450.main'
   ```

# Domain model 

## Diagram
Here is the digram for my domain model

``` mermaid
---
config:
layout: elk
look: classic
theme: default
title: Activity Tracker System
---
classDiagram
direction TB
class obstacle {
text name
coordinate obstaclePosition
getName()
getObstacleCoordinate() coordinate
}
class menu {
text userName
list~gear~ items
list~activity~ exercise
list~map~ mymap
list~statistics~ stat
addGear(gear newGear) nothing
showGear() items
removeGear(gear oldGear) nothing
addMap(map newMap) nothing
showMap() mymap
removeMap(map oldMap) nothing
addActivity(activity newAc) nothing
showActivity() exercise
removeActivity(activity oldAc) nothing
addStat(statistics newStat) nothing
showStat() stat
removeStat(statistics oldStat) nothing
}
class activity {
text name
getName() text
}
class gear {
text name
positiveNumber quality
gearType type
changeQuality(wholeNumber newQuality) : nothing
type() gearType
}
class gearType {
SUPPORT
PROTECTION
NUTRITION
}
class coordinate {
positiveNumber x
positiveNumber y
getX() positiveNumber
getY() positiveNumber
}
class map {
text name
list~obstacle~ obstacles
positiveNumber width
positiveNumber height
getName() text
displayMap()
addObstacle(obstacle newOne) nothing
showObstacle() obstacles
removeObstacle(obstacle oldOne) nothing
}
class statistics {
positiveNumber time
positiveNumber length
averageTime() decimalNumber
averageLength() decimalNumber
}
class route {
coordinate start
coordinate end
checkRoute() valid/ invalid
}
<<record>> activity
<<enumeration>> gearType
<<record>> coordinate

	note for menu "Invariant properties:
		* userName.length >= 1
		* items != null
		* exercise != null
		* mymap != null
		* stat != null
		"
	note for menu"It controls all the system"
	note for map "Invariant properties:
		* name.length >= 1
		* obstacles != null	
		"
	note for statistics "Invariant properties:
		* time > 0
		* length > 0
		"
	note for route "Invariant properties:
		* start != end
	"
	note for gear "Invariant properties:
		* name.length >= 1
		* quality >= 0
		* type != null
	"
	note for obstacle "Invariant properties:
		* name.length >= 1
	"
	note for activity "Invariant properties:
		* name.length >= 1
	"
	
    menu --* map : composed
    menu --* statistics : composed
    menu --* activity : composed
    menu --* gear : composed
    map --o obstacle : aggregates
    map --* route : composed
    obstacle --o coordinate : aggregate
    route ..> obstacle
    route --o coordinate : aggregates
    statistics ..> route
    activity <.. gear
    gear --* gearType : composed
```

