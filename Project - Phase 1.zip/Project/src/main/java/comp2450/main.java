package comp2450;

import comp2450.model.menu;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        System.out.println("Enter your name: ");
        var scan = new Scanner(System.in);
        String name = scan.nextLine();
        menu system = new menu(name);
        system.start();
    }
}
