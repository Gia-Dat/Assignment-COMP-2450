package comp2450.model.exceptions;

public class InvalidCoordinateException extends Exception{
}
