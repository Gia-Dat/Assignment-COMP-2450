package comp2450.model;

/**
 * Represents a coordinate point with x and y values.
 */

public record coordinate(int x, int y) {
    // No need for explicit validation if coordinates can be any numeric values
    public int getX() { return x; }
    public int getY() { return y; }
}