package comp2450.model;

import com.google.common.base.Preconditions;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Represents a game map with obstacles and grid display.
 */

public class map {
    private final String name;
    private final ArrayList<obstacle> obstacles;
    private final Scanner scanner;
    private final int gridWidth;
    private final int gridHeight;
    private final char[][] grid;

    // Grid symbols
    private static final char EMPTY = '.';
    private static final char OBSTACLE = '*';
    private static final char ROUTE = '>';

    public map(String name) {
        // Preconditions
        Preconditions.checkNotNull(name, "Name must not be null");
        Preconditions.checkArgument(name.length() >= 1, "Name must not be empty");

        this.name = name;
        this.obstacles = new ArrayList<>();
        this.scanner = new Scanner(System.in);

        // Default grid size - you can make this configurable
        this.gridWidth = 10;
        this.gridHeight = 10;
        this.grid = new char[gridHeight][gridWidth];
        initializeGrid();
    }

    public map(String name, int width, int height) {
        // Preconditions
        Preconditions.checkNotNull(name, "Name must not be null");
        Preconditions.checkArgument(name.length() >= 1, "Name must not be empty");
        Preconditions.checkArgument(width > 0, "Grid width must be positive");
        Preconditions.checkArgument(height > 0, "Grid height must be positive");

        this.name = name;
        this.obstacles = new ArrayList<>();
        this.scanner = new Scanner(System.in);

        this.gridWidth = width;
        this.gridHeight = height;
        this.grid = new char[gridHeight][gridWidth];
        initializeGrid();
    }

    private void initializeGrid() {
        // Fill grid with empty spaces
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                grid[y][x] = EMPTY;
            }
        }
    }

    public void displayGrid() {
        System.out.println("\n--- Map: " + name + " ---");
        System.out.println("Grid Size: " + gridWidth + "x" + gridHeight);

        // Print legend
        System.out.println("\nLegend:");
        System.out.println(EMPTY + " - Empty location");
        System.out.println(OBSTACLE + " - Obstacle");
        System.out.println(ROUTE + " - Activity route");

        // Print grid with coordinates
        System.out.println("\nGrid:");

        // Print column headers
        System.out.print("   ");
        for (int x = 0; x < gridWidth; x++) {
            System.out.print(x + " ");
        }
        System.out.println();

        // Print grid rows with row headers
        for (int y = 0; y < gridHeight; y++) {
            System.out.print(y + "  ");
            for (int x = 0; x < gridWidth; x++) {
                System.out.print(grid[y][x] + " ");
            }
            System.out.println();
        }
    }

    public void manageObstaclesInteractive() {
        while (true) {
            System.out.println("\n--- Obstacle Management for Map: " + name + " ---");
            System.out.println("1. Add obstacle");
            System.out.println("2. Remove obstacle");
            System.out.println("3. Show all obstacles");
            System.out.println("4. Display grid");
            System.out.println("5. Return to menu");
            System.out.print("Choose an option: ");

            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume newline

                switch (choice) {
                    case 1:
                        addObstacleInteractive();
                        break;
                    case 2:
                        removeObstacleInteractive();
                        break;
                    case 3:
                        showObstacles();
                        break;
                    case 4:
                        displayGrid();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // clear invalid input
            }
        }
    }

    private void addObstacleInteractive() {
        System.out.println("\n--- Add Obstacle to Map: " + name + " ---");

        // Show grid first
        displayGrid();

        // Get obstacle details
        System.out.print("Enter obstacle name: ");
        String obstacleName = scanner.nextLine().trim();

        if (obstacleName.isEmpty()) {
            System.out.println("Obstacle name cannot be empty.");
            return;
        }

        try {
            System.out.print("Enter X coordinate (0-" + (gridWidth-1) + "): ");
            int x = scanner.nextInt();
            System.out.print("Enter Y coordinate (0-" + (gridHeight-1) + "): ");
            int y = scanner.nextInt();
            scanner.nextLine(); // consume newline

            // Validate coordinates
            if (x < 0 || x >= gridWidth || y < 0 || y >= gridHeight) {
                System.out.println("Invalid coordinates! Must be within grid bounds.");
                return;
            }

            coordinate obstacleCoord = new coordinate(x, y);
            obstacle newObstacle = new obstacle(obstacleName, obstacleCoord);

            addObstacle(newObstacle);
            System.out.println("Obstacle '" + obstacleName + "' added successfully to map '" + name + "'");

        } catch (Exception e) {
            System.out.println("Invalid coordinate input. Please enter integer values.");
            scanner.nextLine(); // clear invalid input
        }
    }

    public void addObstacle(obstacle newObstacle) {
        Preconditions.checkNotNull(newObstacle, "newObstacle must not be null");

        // Update grid
        coordinate coord = newObstacle.getObstacleCoordinate();
        int x = (int) coord.getX();
        int y = (int) coord.getY();

        if (x >= 0 && x < gridWidth && y >= 0 && y < gridHeight) {
            grid[y][x] = OBSTACLE;
        }

        obstacles.add(newObstacle);

        // Postcondition
        Preconditions.checkState(obstacles.contains(newObstacle),
                "Postcondition failed: obstacle not added");
    }

    private void removeObstacleInteractive() {
        System.out.println("\n--- Remove Obstacle from Map: " + name + " ---");

        ArrayList<obstacle> currentObstacles = new ArrayList<>(obstacles);
        if (currentObstacles.isEmpty()) {
            System.out.println("No obstacles available to remove from this map.");
            return;
        }

        // Show obstacles for selection
        System.out.println("Obstacles in this map:");
        for (int i = 0; i < currentObstacles.size(); i++) {
            obstacle o = currentObstacles.get(i);
            coordinate coord = o.getObstacleCoordinate();
            System.out.println((i + 1) + ". " + o.getName() + " at (" + (int)coord.getX() + ", " + (int)coord.getY() + ")");
        }

        try {
            System.out.print("Select obstacle to remove (number): ");
            int obstacleChoice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if (obstacleChoice >= 1 && obstacleChoice <= currentObstacles.size()) {
                obstacle obstacleToRemove = currentObstacles.get(obstacleChoice - 1);
                removeObstacle(obstacleToRemove);
                System.out.println("Obstacle '" + obstacleToRemove.getName() + "' removed successfully.");
            } else {
                System.out.println("Invalid obstacle selection.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.nextLine(); // clear invalid input
        }
    }

    public void removeObstacle(obstacle oldObstacle) {
        Preconditions.checkNotNull(oldObstacle, "Obstacle must not be null");
        Preconditions.checkState(obstacles.contains(oldObstacle),
                "Obstacle must exist in the map");

        // Update grid
        coordinate coord = oldObstacle.getObstacleCoordinate();
        int x = (int) coord.getX();
        int y = (int) coord.getY();

        if (x >= 0 && x < gridWidth && y >= 0 && y < gridHeight) {
            grid[y][x] = EMPTY;
        }

        boolean removed = obstacles.remove(oldObstacle);

        // Postcondition
        Preconditions.checkState(removed, "Postcondition failed: obstacle not removed");
    }

    public void showObstacles() {
        System.out.println("\n--- All Obstacles in Map: " + name + " ---");

        var obstacleList = new ArrayList<obstacle>(obstacles);

        if (obstacleList.isEmpty()) {
            System.out.println("No obstacles in this map.");
        } else {
            for (int i = 0; i < obstacleList.size(); i++) {
                obstacle o = obstacleList.get(i);
                coordinate coord = o.getObstacleCoordinate();
                System.out.println((i + 1) + ". " + o.getName() + " at (" + (int)coord.getX() + ", " + (int)coord.getY() + ")");
            }
        }
    }

    // Method to add route path (for future use)
    public void addRoutePath(ArrayList<coordinate> route) {
        for (coordinate coord : route) {
            int x = (int) coord.getX();
            int y = (int) coord.getY();

            if (x >= 0 && x < gridWidth && y >= 0 && y < gridHeight && grid[y][x] == EMPTY) {
                grid[y][x] = ROUTE;
            }
        }
    }

    // Method to clear route path (for future use)
    public void clearRoutePath() {
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                if (grid[y][x] == ROUTE) {
                    grid[y][x] = EMPTY;
                }
            }
        }
    }

    public String getName() {
        // Invariant check
        Preconditions.checkState(name != null && name.length() >= 1,
                "Invariant violated: Map name must not be null or empty");
        return name;
    }

    // Getters for grid properties
    public int getGridWidth() {
        return gridWidth;
    }

    public int getGridHeight() {
        return gridHeight;
    }

}