package comp2450.model;

/**
 * Types of gear categories.
 */
public enum gearType {
    SUPPORT,
    PROTECTION,
    NUTRITION
}

